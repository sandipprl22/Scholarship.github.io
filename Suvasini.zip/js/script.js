function openMenu(){
        document.getElementById("navbar").style.left = "0px";
}

function closeMenu(){
    document.getElementById("navbar").style.left = "-280px";

}
